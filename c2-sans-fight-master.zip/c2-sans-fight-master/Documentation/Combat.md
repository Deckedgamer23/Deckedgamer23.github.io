# Combat zone behaviors

### CombatZoneSpeed ###
Sets speed of combat zone resize

* Speed

### CombatZoneResize ###
Resizes the combat zone to the new bounds, and executes FinishAction, when it is done
Generally¸ FinishAction is TLResume

* LeftPosition
* TopPosition
* RightPosition
* BottomPosition
* FinishAction

### CombatZoneResizeAuto ###
Instantly resize the combat zone

* LeftPosition
* TopPosition
* RightPosition
* BottomPosition

### GetHeartPos ###
Stores the heart position in two variables

* XHeartVariableName
* YHeartVariableName
