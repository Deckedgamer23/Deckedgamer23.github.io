# Sans behaviors #

### SansAnimation ###
Perform one of the multi-sprite animations (Idle, HeadBob, Tired)

* AnimationName

### SansBody ###
Show one of the full body animations (HandUp, HandDown, HandLeft, HandRight)

* AnimationName

### SansTorso ###
Show one of the torso animations (Default, Shrug)

* AnimationName

### Sans Head ###
Show one of the head animations (Default, LookLeft, Wink, ClosedEyes, NoEyes, BlueEye, Tired1, Tired2)

* AnimationName

### SansSweat ###
How much sweat Sans should show (0 - 3)

* SweatLevel

### SansX ###
Move Sans to a horizontal position

* XPosition

### SansRepeat ###
Make Sans scroll across the screen

* NO ARGUMENTS

### SansEndRepeat ###
Stop Sans from scrolling

* NO ARGUMENTS

### SansText ###
Sans speech bubble.
RECOMMENDATION: Only show short text

* Text
